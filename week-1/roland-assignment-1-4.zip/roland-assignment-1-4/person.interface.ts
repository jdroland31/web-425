/**
 * Title: Assignment 1.4
 * Author: Professor Richard Krasso
 * Date: 12/21/2020
 * Modified By: Jonathan Roland
 * Description: demonstrate a basic Angular application
**/

//export the IPerson interface with first and last name string types
export interface IPerson {
    firstName: string;
    lastName: string;
}